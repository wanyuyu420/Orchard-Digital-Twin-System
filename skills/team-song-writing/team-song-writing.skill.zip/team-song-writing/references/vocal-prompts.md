# 人声音色与声乐提示词指南

## 目录
- 人声标签使用
- 主唱音色类型
- 童声与少年音
- 合唱与和声
- 特效与风格音色
- 声乐技巧词典

---

## 人声标签使用

在歌词全文前添加普通话演唱标签：
```
[This is a Mandarin song]
```

---

## 主唱音色类型

### 男声声部
| 类型 | 英文 | 特点 | 适用风格 |
|------|------|------|----------|
| 男高音 | male tenor | 明亮、高亢 | 流行、抒情 |
| 男中音 | male baritone | 温暖、厚实 | 流行、摇滚 |
| 男低音 | male bass | 低沉、有力量 | 叙事、戏剧 |

### 女声声部
| 类型 | 英文 | 特点 | 适用风格 |
|------|------|------|----------|
| 女高音 | female soprano | 清亮、穿透力强 | 抒情、古典 |
| 女中音 | female mezzo | 温柔、圆润 | 流行、民谣 |
| 女低音 | female alto | 醇厚、有磁性 | 爵士、R&B |

### 特殊音色
- **电子人声**：electronic vocal / robotic voice（带AutoTune/合成质感）
- **清唱自然人声**：natural vocal / clean vocal（自然、真实、少修饰）

**提示**：在prompt里加上 `[lead]` 或 `[solo]` 强调主唱角色

---

## 童声与少年音

| 类型 | 英文 | 特点 |
|------|------|------|
| 童声 | child voice / children's choir | 纯净、天真 |
| 女童声 | female child voice | 稚嫩、甜美 |
| 男童声 | boy soprano | 清亮、高亢 |
| 少年声 | teen voice / adolescent vocal | 青涩 |
| 童声合唱 | children's choir | 多声部、梦幻感 |
| 卡通童声 | cartoon child voice | 夸张、可爱 |

**提示**：童声常用于副歌或和声，能营造纯真氛围

---

## 合唱与和声

| 类型 | 英文 | 说明 |
|------|------|------|
| 男女合唱 | male & female duet | 一男一女对唱 |
| 女声合唱 | female choir | 多层次女声和声 |
| 男声合唱 | male choir | 厚重稳健的男声群体 |
| 混合合唱 | mixed choir | 男女混合 |
| 背景和声 | background vocals / backing harmonies | 副歌衬托 |
| 童声和声 | child harmony | 童声作和声衬托 |

**提示**：写prompt时加 `[layered]` 或 `[stacked harmonies]` 强调多层感

---

## 特效与风格音色

| 类型 | 英文 | 特点 |
|------|------|------|
| 氛围人声 | ambient vocal / ethereal voice | 空灵、梦幻 |
| 电音人声 | vocoder / autotuned voice | 电音调制 |
| 低语人声 | whisper voice | 轻声、亲密 |
| 空灵女声 | airy female voice / angelic voice | 呼吸感强 |
| 流行唱腔 | pop vocal | 现代流行风格 |
| R&B唱腔 | R&B vocal | 慵懒、滑音 |
| 摇滚唱腔 | rock vocal | 有爆发力 |
| 说唱 | rap vocal / hip-hop vocal | 节奏感强 |
| 气声唱腔 | breathy vocal | 轻柔、呼吸感 |
| 颤音人声 | vibrato vocal | 自然或人工颤音 |

**提示**：结合效果词如 "reverb", "delay", "grainy" 可得到更明显的风格化效果

---

## 声乐技巧词典

### 音色特征
Soft, Sharp, Steady, Ethereal, Full, Bright, Rich, Crisp, Delicate, Raspy, Deep, Clear, Moist, Dry, Metallic, Lingering, Smooth, Rough, Resonant

### 发音与技术表现
- 吞音 (Swallowed Sound)
- 轻声耳语 (Whispering)
- 哼鸣 (Humming)
- 颤音 (Vibrato)
- 吐字清晰 (Enunciated)
- 拖长音 (Sustained Notes)
- 流畅 (Smooth Flow)
- 快速吐词 (Fast-Talking)
- 情感爆发 (Emotional Outburst)
- 喘息 (Gasping)
- 清唱 (A Capella)

### 情感传达技巧
- 发音夸张 (Exaggerated Pronunciation)
- 高频清晰 (Clear High Frequencies)
- 低频沉稳 (Solid Low Frequencies)
- 停顿 (Pause)
- 高低起伏 (Pitch Modulation)
- 吐字连贯 (Legato)
- 气息发音 (Breathy Sound)

### 发声技巧
- 头声 (Head Voice)
- 胸声 (Chest Voice)
- 腹部发声 (Diaphragmatic Voice)
- 轻唱 (Soft Singing)
- 强唱 (Belting)
- 呼吸控制 (Breath Control)
- 混声 (Mixed Voice)
- 转音 (Voice Breaks)

### 音质控制
- 音质变化 (Tone Variation)
- 胸腔共鸣 (Chest Resonance)
- 鼻腔共鸣 (Nasal Resonance)
- 喉腔共鸣 (Throat Resonance)
- 气声效果 (Breathy Tone)

### 情感表现结合
- 低语式 (Whispered Style)
- 震撼人心的声音 (Heart-Wrenching Voice)
- 嘶哑歌唱 (Raspy Singing)
- 动情歌唱 (Emotional Singing)
- 感人的演唱 (Touching Performance)
- 抽泣式发音 (Crying Tone)

---

## 常用组合示例

| 组合 | 提示词 |
|------|--------|
| 女声主唱+童声和声 | female lead vocal with child backing choir |
| 男中音主唱+空灵女声副歌 | male baritone lead with ethereal female chorus |
| 女中音独唱+电子人声层叠 | female mezzo solo with layered robotic harmony |
| 少年音主唱+童声合唱尾段 | teen lead vocal with children's choir outro |
| 双人合唱（男女） | male & female duet pop style |

---

## 精准指令使用

把这些词汇用 `[ ]` 括起来放在提示词中：

```
[This is a Mandarin song]
[ female lead vocal with ethereal backing harmonies ]
[ soft and breathy vocal ]
[ emotional chorus with vibrato ]
```

### 情绪关键词
- dreamy（梦幻）
- lofi（低保真）
- cinematic（电影感）
- emotional（情感）
- uplifting（振奋）

### 制作细节
- light reverb（轻柔混响）
- light harmonies（轻柔和声）
- heavy breathing（重呼吸感）
- warm tone（温暖音色）
